<?php
include('config.php');

$search = "";
$search_sql = "";
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $search_sql = " WHERE REPLACE(REPLACE(name, '.', ''), ' ', '') LIKE REPLACE(REPLACE('%$search%', '.', ''), ' ', '')
                 OR REPLACE(REPLACE(course, '.', ''), ' ', '') LIKE REPLACE(REPLACE('%$search%', '.', ''), ' ', '')";
}

echo "<a href='form.php'><button style='margin-bottom: 10px;'>Add Student</button></a>";

echo "<form method='GET' style='margin-bottom: 20px;'>
        <input type='text' name='search' placeholder='Search by name or course' value='" . htmlspecialchars($search) . "' />
        <button type='submit'>Search</button>
      </form>";


$sql = "SELECT id, name, email, phone, course FROM registration" . $search_sql;
$result = mysqli_query($conn, $sql);

echo "<style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ccc;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #fafafa;
        }
        tr:hover {
            background-color: #e8f0fe;
        }
        caption {
            font-size: 1.5em;
            margin-bottom: 10px;
            font-weight: bold;
        }
      </style>";

if (mysqli_num_rows($result) > 0) {
    echo "<table><caption>Student Registration List</caption>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Course</th><th>Actions</th></tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        // print_r($row); die;
        echo "<tr>";
        echo "<td>{$row["id"]}</td>";
        echo "<td>{$row["name"]}</td>";
        echo "<td>{$row["email"]}</td>";
        echo "<td>{$row["phone"]}</td>";
        echo "<td>{$row["course"]}</td>";
        echo "<td>
                <a href='edit.php?id={$row["id"]}'>Edit</a> | 
                <a href='delete.php?id=" . $row["id"] . "'>Delete</a>
              </td>";
        echo "</tr>";
    }
    echo "</table>";
} 

mysqli_close($conn);
?>

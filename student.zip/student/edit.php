<?php
session_start(); 

include('config.php');

$id = $name = $email = $phone = $course = "";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM registration WHERE id = $id";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
        $course = $row['course'];
    } else {
        echo "Student not found.";
        exit();
    }
}

if (isset($_POST['update'])) {
    $id     = $_POST['id'];
    $name   = $_POST['name'];
    $email  = $_POST['email'];
    $phone  = $_POST['phone'];
    $course = $_POST['course'];

    $sql = "UPDATE registration SET name='$name', email='$email', phone='$phone', course='$course' WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['success'] = "Student updated successfully!";
        header("Location: list.php"); 
        exit();
    } else {
        $_SESSION['error'] = "Error updating record: " . mysqli_error($conn);
        header("Location: edit.php?id=$id"); 
        exit();
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Edit Student</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      padding: 50px;
    }
    .form-container {
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      width: 400px;
      margin: auto;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    label {
      font-weight: bold;
      display: block;
      margin: 10px 0 5px;
    }
    input[type="text"], input[type="email"], input[type="tel"], select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      width: 100%;
      padding: 12px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    button:hover {
      background-color: #45a049;
    }
    .success {
        color: green;
        font-weight: bold;
    }
    .error {
        color: red;
        font-weight: bold;
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2>Edit Student</h2>

  <?php if (isset($_SESSION['success'])): ?>
      <div class="success">
          <?php echo $_SESSION['success']; ?>
      </div>
      <?php unset($_SESSION['success']); ?>
  <?php endif; ?>

  <?php if (isset($_SESSION['error'])): ?>
      <div class="error">
          <?php echo $_SESSION['error']; ?>
      </div>
      <?php unset($_SESSION['error']); ?> 
  <?php endif; ?>

  <form action="" method="POST">
    <input type="hidden" name="id" value="<?php echo $id; ?>">

    <label for="name">Name:</label>
    <input type="text" id="name" name="name" value="<?php echo $name; ?>" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>

    <label for="phone">Phone:</label>
    <input type="tel" id="phone" name="phone" value="<?php echo $phone; ?>" required>

    <label for="course">Course:</label>
    <select id="course" name="course" required>
      <option value="">-- Select Course --</option>
      <option value="BCA" <?php if ($course == "BCA") echo "selected"; ?>>BCA</option>
      <option value="MCA" <?php if ($course == "MCA") echo "selected"; ?>>MCA</option>
      <option value="B.Tech" <?php if ($course == "B.Tech") echo "selected"; ?>>B.Tech</option>
      <option value="MBA" <?php if ($course == "MBA") echo "selected"; ?>>MBA</option>
    </select>

    <button type="submit" name="update">Update Student</button>
  </form>
</div>

</body>
</html>

<?php

include('config.php');

if (isset($_GET['id'])) {
    $id = $_GET['id']; 
    $sql = "DELETE FROM registration WHERE id = $id";
    if (mysqli_query($conn, $sql)) {

        header("Location: list.php"); 
        exit();
    } else {
          
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
mysqli_close($conn);
?>
